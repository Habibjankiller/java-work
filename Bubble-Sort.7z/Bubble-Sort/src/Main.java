import java.util.Arrays;
import java.util.Iterator;

public class Main {
	public static void main(String args[]) {
		int[] arr = {5, 8, 3, 2, 7};
		
		//This Loop is for Iterating Passes
		for (int i = 0; i < arr.length; i++) {
			
			//This Loop is for Iterating over the inner element
			//for comparing greater number
			for (int j = 0; j < arr.length - 1; j++) {
				
				//Comparing Element for greater
				//If previous Element is Greater than Next
				//Then we shuffle It
				if (arr[j] > arr[j + 1]) {
					int present = arr[j];
					int forward = arr[j + 1];
					arr[j] = forward;
					arr[j + 1] = present;
				}
			}
		}
		
		//Printing The Array After Bubble Sort Algorithm
		System.out.println(Arrays.toString(arr));
	}
}
